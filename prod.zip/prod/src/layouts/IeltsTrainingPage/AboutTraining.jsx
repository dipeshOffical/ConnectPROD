import { Outlet } from "react-router";

const AboutTraining = () => {
    return (
        <Outlet />
    );
}

export default AboutTraining;